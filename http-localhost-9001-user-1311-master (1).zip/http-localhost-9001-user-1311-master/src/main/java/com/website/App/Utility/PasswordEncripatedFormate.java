/**
 * 
 */
package com.website.App.Utility;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

/**
 * @author 10698333
 *
 */
public class PasswordEncripatedFormate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
	
	}

}
