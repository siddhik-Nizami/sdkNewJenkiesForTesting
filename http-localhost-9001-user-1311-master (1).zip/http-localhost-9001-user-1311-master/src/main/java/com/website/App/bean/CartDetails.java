/**
 * 
 */
package com.website.App.bean;

/**
 * @author 10698333
 *
 */
public class CartDetails {

	private int id;
	private String cardName;
	private String cvv;
	
}
