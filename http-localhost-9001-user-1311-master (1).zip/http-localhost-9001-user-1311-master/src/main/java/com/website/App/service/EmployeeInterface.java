/**
 * 
 */
package com.website.App.service;

import com.website.App.bean.Employee;

/**
 * @author 10698333
 *
 */
public interface EmployeeInterface {
	
	public Employee save(Employee emp);
	

}
