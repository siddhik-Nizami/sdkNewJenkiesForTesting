/**
 * 
 */
package com.website.App.exception;

/**
 * @author 10698333
 *
 */
public class ProductDataNotFounkd extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7801975389138522573L;
	
public ProductDataNotFounkd(String smg) {
	super(smg);
}
}
