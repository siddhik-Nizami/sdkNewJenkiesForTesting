package com.website.App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EWebSiteProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
