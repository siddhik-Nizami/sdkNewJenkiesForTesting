/**
 * 
 */
package com.website.App;

import org.springframework.beans.factory.annotation.Autowired;

import com.website.App.bean.User;
import com.website.App.exception.EmailIDOrMatached;
import com.website.App.repository.UserJpa;

/**
 * @author 10698333
 *
 */

public class UserEmailIdCheck  {
	
	
	/*public static void main(String[] args) throws Exception{
		@Autowired
		UserJpa userDao ;
		String email="siddhik@gmail.com";

		User user = new User();
		user=userDao.findByEmail(email);
		if(email==user.getEmail()) {
			throw new EmailIDOrMatached(user+"Email named matched");
		}*/
	}


